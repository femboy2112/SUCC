# RH / observer / benevolent-demon research pack

Read `RESEARCH_NOTE.md` for definitions, proofs, sources, and claim boundaries.

Run the exact finite verifier with Python 3:

```bash
python verify.py
```

`verify.py` uses only the standard library. It reads `certificates.json` and writes
`verification_results.json`. Norm upper bounds include the entire infinite tail;
no truncated numerical norm is treated as a certificate.

`generate_candidates.py` is optional and requires NumPy and SciPy. It proposes
coefficients numerically and repairs the prefix constraints with exact rational
linear algebra. Its output must be checked with `verify.py`.

The negative stress-test result concerns that specific generated coefficient
vector. It is not a rigorous lower bound on the optimum over all coefficient
vectors. None of the finite computations proves or refutes RH.

The main number-theory equivalence is established literature, not claimed as a
new discovery. The supplied observer deductions are proved in the note, without
any claim that they have never previously appeared in equivalent form.
