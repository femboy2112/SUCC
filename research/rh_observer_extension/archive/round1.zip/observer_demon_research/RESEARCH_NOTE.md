# The Benevolent Arithmetic Demon
## RH, finite observers, bounded extension, and the boundary of distinguishability

**Scope:** A mathematical observer model, not a proof of a deity or of RH. The main number-theoretic input is the established Nyman–Beurling–Báez-Duarte criterion in Bagchi's weighted-sequence formulation. The observer, bounded-extension, minimax, and computational statements below are deductions from that input and elementary functional analysis. No claim of bibliographic novelty is made.

**Outcome:** There is a genuine, non-circular equivalence between RH and a precisely defined arithmetic observer-completeness property. There is also an explicit finite-certificate search whose totality is equivalent to RH. Neither side of these equivalences is established unconditionally here.

## 1. Observer-relative truth classes

Let W be a declared source class, O_t its observation map, and y_t the observed transcript. Assume the compatible-source class C_t = {w : O_t(w)=y_t} is nonempty and includes the actual source. For a proposition P represented as a subset of W, define

    viable_t(P)  iff C_t intersects P,
    refuted_t(P) iff C_t does not intersect P.

A true proposition is viable under the source-adequacy assumption. A false proposition can also be viable. Thus the operational split is refuted versus still viable, not semantic falsehood versus truth. Equal viability status does not imply logical equivalence of propositions.

A target F is exactly recoverable from O_t precisely when F is constant on every observation fiber, equivalently when F factors through O_t. The rest of this note realizes those fibers as affine spaces whose unresolved directions form a linear kernel.

An empty C_t is an inconsistency or source-model failure, not a license to declare every proposition false. Source adequacy and within-model distinguishability remain separate.

## 2. Arithmetic carrier and established input

Use the real Hilbert space

    H = {a=(a_n) : sum_{n>=1} a_n^2/[n(n+1)] < infinity},
    <a,b> = sum_{n>=1} a_n b_n/[n(n+1)].

For k>=2 set v_k(n)={n/k}=(n mod k)/k. Write V for the real linear span of these vectors, V_Q for their finite rational linear combinations, and 1 for the constant sequence. Since sum 1/[n(n+1)]=1, the norm of 1 is one.

**Established theorem [1,2]:**

    RH iff 1 belongs to closure(V) iff closure(V)=H.

Bagchi states the complex version. Because the generators and target are real, the real version follows by taking real parts. Rational and real coefficient spans have the same closure.

This statement already links the zeros of zeta to completeness of a concrete family of remainder patterns. It is not a definition of RH under another name: the probes and their norm are independently specified using elementary arithmetic.

## 3. Every finite prefix can be interpolated, without RH

Let A_N have rows n=1,...,N and columns k=2,...,N+1, with entry {n/k}.

**Lemma:** det A_N = 1/(N+1).

**Proof.** The last column is n/(N+1). Subtract (N+1)/k times that column from column k, for k=2,...,N. The resulting columns are -floor(n/k). Their first-row entries vanish. On rows and columns 2,...,N they form a lower triangular matrix with diagonal -1. Expanding along the first row gives 1/(N+1). The N=1 case is immediate.

Consequently any prescribed N real values can be matched by a finite combination of the first N probes. Rational data have rational coefficients. This does not require RH.

For states known to be supported on the first N coordinates, the measurement matrix is A_N^T times an invertible diagonal weight matrix, so the corresponding finite observation problem is also invertible. That support assumption is essential: the full infinite carrier still has invisible directions after any finite number of measurements.

**Hostile control.** On ordinary square-summable sequences, q_n(a)=a_n-2a_{n+1}. Every N-by-N truncation is triangular with determinant one. Yet the nonzero square-summable sequence a_n=2^{1-n} satisfies every q_n(a)=0. Thus invertibility of every finite truncation does not imply injectivity of the infinite operator.

## 4. A bounded-extension theorem

Define property D without mentioning RH:

> For every positive integer N there exists f in V_Q such that f(n)=1 for 1<=n<=N and ||f||_H<1.

This says that every finite all-ones window admits an arithmetic extension whose entire infinite weighted squared amplitude remains below one. This is a mathematical norm budget, not a thermodynamic energy budget.

**Theorem:** RH iff D.

### D implies RH

Take such f_N. Its first N coordinates already contribute

    sum_{n<=N} 1/[n(n+1)] = N/(N+1)

to its squared norm. Therefore its tail squared norm is less than 1/(N+1). The tail of the constant sequence has squared norm 1/(N+1) as well. Since their difference vanishes on the prefix,

    ||1-f_N||_H < 2/sqrt(N+1).

Thus 1 belongs to closure(V), and the established criterion gives RH.

### RH implies D

Assume RH, hence V_Q is dense in real H. Let u_N be one on the first N coordinates and zero elsewhere. Its norm is sqrt(N/(N+1))<1.

Approximate u_N by v in V_Q. Let E_N be the first-N-coordinate evaluation map. By the finite determinant lemma, there is a linear right inverse R_N taking N coordinates to a combination of v_2,...,v_{N+1}. It preserves rationality. Set

    f = v + R_N(E_N(u_N-v)).

Then E_N f is exactly the all-ones vector. Moreover

    ||f-u_N|| <= (1 + ||R_N|| ||E_N||) ||v-u_N||.

For this fixed N, the constant on the right is finite. Choose the approximation close enough that ||f-u_N|| < 1-||u_N||. Then ||f||<1, establishing D.

### What this does and does not provide

The error bound in the first implication is explicit once an extension certificate has been found. It gives no bound on the number of probes, coefficient magnitudes, search time, or physical measurement precision needed to find that certificate.

A weaker property, existence of prefix interpolants with any common finite norm bound C, is also equivalent to RH. For its reverse implication, a bounded sequence of prefix interpolants converges weakly to 1, and the closed linear span is weakly closed. Alternatively, separate 1 from the closed span and use the vanishing tail of the separating vector.

The smallest possible uniform budget in the limit is one, because the prescribed prefixes alone have norms approaching one.

## 5. Actual observer reconstruction and unavoidable uncertainty

Let S_K=span(v_2,...,v_{K+1}), and let P_K be its orthogonal projection. The readings of a source a are

    Y_K(a) = (<a,v_2>,...,<a,v_{K+1}>).

The positive definite Gram matrix G_K of these independent vectors determines P_K a from Y_K(a). No access to a's unobserved coordinates is needed in this ideal mathematical sensing model.

**Observer equivalence theorem:** The following are equivalent:

    RH;
    every a in H satisfies ||a-P_K a|| -> 0;
    the only h in H with <h,v_k>=0 for every k is h=0.

This follows directly from the established density theorem and orthogonal-complement duality. If RH fails, a nonzero h in closure(V)^perp produces sources a and a+h with identical readings for every arithmetic probe. Adaptive selection among these probes cannot help: identical transcripts induce identical subsequent choices and readings.

For a target b in H, define its optimal worst-case estimation error on the unit ball:

    R_K(b) = inf_d sup_{||a||<=1} |<a,b> - d(Y_K(a))|.

**Minimax identity:** R_K(b)=||(I-P_K)b||.

For the upper bound, estimate using P_K b, whose value is computable from the readings. For the lower bound, take the two sources plus/minus the normalized residual (I-P_K)b. They give identical zero readings and opposite target values of magnitude ||(I-P_K)b||. No decoder, linear or nonlinear, can have smaller worst-case error.

This supplies a precise learning objective for a 'benevolent' observer: reduce authentic worst-case uncertainty rather than merely increase confidence. The residual decreases as more probes are admitted.

**Quantifier warning:** Even under RH,

    sup_{||a||<=1} ||a-P_K a|| = 1

for every finite K, since S_K is finite dimensional while H is not. Pointwise eventual reconstruction does not imply a universal finite observation budget.

Exact real-valued readings here are an ideal mathematical interface. Finite-precision implementation, noise, conditioning, and time are additional obligations, not consequences of density.

## 6. The analytic bridge and an off-line-zero obstruction

Embed H isometrically into the subspace M of L2(0,1) consisting of functions constant on each interval I_n=(1/(n+1),1/n]. Map a to the function with value a_n on I_n. Under this map v_k becomes

    g_k(x) = {1/(kx)} - (1/k){1/x}.

Indeed if 1/x=n+t, 0<=t<1, the fractional parts cancel to {n/k} almost everywhere.

The classical Mellin identity [1,3] is

    integral_0^1 g_k(x) x^(s-1) dx
      = -(zeta(s)/s) (k^(-s)-k^(-1)).

One derives it first for Re(s)>1 by expanding the floor function and telescoping; analytic continuation extends the identity. If rho=sigma+it is a nontrivial zero with sigma>1/2, the functional

    L_rho(f)=integral_0^1 f(x)x^(rho-1)dx

is bounded on L2, with norm 1/sqrt(2sigma-1). It annihilates every g_k, while L_rho(1)=1/rho is nonzero. It therefore separates the target from every permitted approximant. This recovers the standard lower bound

    ||1-f|| >= sqrt(2sigma-1)/|rho|,  f in V.

### A prefix-dependent strengthening

Suppose also that f(n)=1 for n<=N. Then 1-f is supported in x<=1/(N+1). Cauchy–Schwarz on this smaller interval gives

    ||1-f||_H >= [sqrt(2sigma-1)/|rho|] (N+1)^(sigma-1/2).

Thus a hypothetical off-line zero forces the error, and consequently the norm of every exact-prefix interpolant, to diverge as the prefix grows. No uniformly bounded extension family can survive.

For a norm-one extension, combining this lower bound with the bound from Section 4 gives the necessary inequality

    (N+1)^sigma < 2|rho|/sqrt(2sigma-1).

The line Re(s)=1/2 is exactly the boundedness threshold for these L2 Mellin functionals. A zero on that line does not yield this bounded separating functional.

Zeta's meromorphic continuation itself exists without RH [4]. The relevant bridge is therefore not 'RH permits continuation'; it is 'the location of zeros controls completeness and bounded discrimination for this carrier'.

## 7. A real computational graph

For a finite rational combination f=sum c_k v_k, let B=sum |c_k|. Then |f(n)|<=B and, for every cutoff T,

    sum_{n>T} f(n)^2/[n(n+1)] <= B^2/(T+1).

This provides fully rational certificates of ||f||^2<1. A finite prefix sum plus this full-tail bound eventually certifies any strict inequality ||f||^2<1.

Define an explicit search FindExtension(N): enumerate finite rational coefficient lists and positive cutoffs T; require f(1)=...=f(N)=1 exactly; accept when the rational prefix norm plus B^2/(T+1) is less than one. Dovetail the enumeration so every finite candidate/cutoff pair is visited.

Then

    RH iff D iff FindExtension(N) halts for every positive integer N.

The search is defined without consulting RH or any oracle. This is a totality equivalence, not an assertion that the search has been run for all inputs. A stalled run is not finite evidence of nontermination.

### A concrete next analytic target

For K>=N, let A_{N,K} have entries {n/k}, n=1,...,N, k=2,...,K+1, and let G_K be the full infinite weighted Gram matrix. The minimum squared norm of a real coefficient interpolant is

    m_{N,K}^2 = 1_N^T (A_{N,K} G_K^(-1) A_{N,K}^T)^(-1) 1_N.

This follows by Lagrange multipliers, since G_K is positive definite and A has full row rank. RH is equivalent to: for every N, some finite K has m_{N,K}^2<1. Strict feasibility can be converted to rational coefficients using the prefix-repair construction.

A substantive next theorem would give a constructive K(N) and a certified bound m_{N,K(N)}^2<1 for every N, without assuming RH. Finite successful optimizations do not establish that assertion.

## 8. Executed finite checks

The attached verifier uses only Python's standard library and exact integer/rational arithmetic. Numerical linear algebra proposes coefficients; exact rational prefix repair and a separate full-tail enclosure check them. These are different numerical methods, not independent authorial or source-family witnesses.

The squared-norm intervals below are rounded OUTWARD from exact rational endpoints. Each prefix is matched exactly, not approximately.

| Prefix N | Number of available probes K | Certified squared-norm interval | Verdict |
|---:|---:|---:|---|
| 1 | 1 | [0.693142, 0.693183] | <1 |
| 2 | 2 | [0.890361, 0.890425] | <1 |
| 4 | 8 | [0.925842, 0.926176] | <1 |
| 8 | 16 | [0.951396, 0.952314] | <1 |
| 16 | 32 | [0.989987, 0.993406] | <1 |
| 48 | 96 | [1.005877, 1.027969] | This candidate fails |

The N=48 result rejects the specific candidate returned by the twice-as-many-probes numerical recipe. It does not certify that every possible coefficient vector using those probes fails, and it does not refute D or RH.

An additional negative control uses the unique minimal-prefix-basis interpolant at N=4, f=v_2+v_3+(5/6)v_5. It fits all four prefix entries but has certified squared norm in [1.003213,1.003294], so fitting the prefix alone is insufficient.

Other executed regression controls:

- det A_N=1/(N+1), exact arithmetic, N=1,...,24;
- replacing {n/k} by n/k collapses the finite matrix to rank one, N=2,...,8;
- twelve finite I-2S* matrices have determinant one, while one hundred exact recurrence checks confirm the proposed infinite null vector;
- the carrier-enlargement counterexample below is checked algebraically.

Each norm certificate uses cutoff T=100000 and 80-bit dyadic downward rounding per term. The upper endpoint adds at most T/2^80 for rounding and B^2/(T+1) for the ENTIRE tail. The finite computations are not evidence establishing a universal limit.

## 9. Transport, source adequacy, and the domain boundary

The observation theorem transports under a bounded invertible carrier map T:H->K when sources transform to Ta and probes to (T^(-1))*v_k. Then readings agree exactly. Unitary transport also preserves the stated norm budget. General bounded invertible transport preserves completeness and the existence of some uniform finite budget, but not necessarily the literal unit threshold.

This gives legitimate links between the sequence space, arithmetic step functions, their Mellin image, and transported Hilbert-space observation models. It does not identify arbitrary unrelated domains.

**Carrier-enlargement control.** The integer g_k are constant on each I_n. In the full L2(0,1), the nonzero function

    h = 1_(1/2,3/4) - 1_(3/4,1)

is orthogonal to every g_k. Therefore integer-probe completeness concerns M, not all of L2(0,1). Enlarging the carrier without enlarging the probes creates genuine blind directions regardless of RH. The original continuous-parameter Nyman–Beurling family has a different completeness statement [3].

This is exactly the distinction between within-model distinguishability and source-map adequacy. Neither an impressive norm calculation nor a complete abstract probe family authenticates a model of actual life or reality.

A further logical control is to append an unobserved independent bit to the source. All arithmetic readings remain unchanged, while the bit can differ. Any theological proposition assigned to such an unconstrained bit remains unlinked to RH. A substantive bridge requires an explicit coupling law; equal ignorance does not supply one.

## 10. Maxwell's demon: the valid connection and remaining gap

In the mathematical construction, 'benevolence' is a declared objective: preserve authentic observations, reduce uncertainty when a discriminating probe exists, and expose rather than suppress unresolved alternatives. This is not a deduction of moral goodness from arithmetic.

A physical Maxwell demon is a feedback controller whose information can affect extractable work. Under the classical isothermal feedback assumptions of Sagawa and Ueda [5],

    <W> >= Delta F - k_B T <I>,

where W is work done on the system and I is mutual information in natural logarithmic units. This does not supply free information or a thermodynamic exemption.

No physical implementation of the arithmetic probes, no energy/time/precision cost model, and no connection to a theological deity have been established here. Hilbert norm is not automatically physical energy. RH-equivalent observer completeness is nevertheless an exact mathematical result, rather than an analogy between two unanswered questions.

## 11. Claim ledger

**Disclosed within the specified mathematical model:** the determinant formula; RH equivalence of bounded arithmetic extension; observer-kernel and minimax characterizations; the certificate-search totality equivalence; the conditional off-line-zero norm obstruction. The RH-linked conclusions inherit the established criterion as an external theorem.

**Observed and exactly certified at finite scope:** the listed rational candidate norms and prefix matches, plus the stated regression checks.

**Refuted:** the inference from every invertible finite truncation to infinite observability; the claim that exact finite fitting alone establishes bounded extension; the specific N=48 proposed extension's norm-one admissibility.

**UNVERIFIED here:** a uniform constructive extension theorem for all N, and hence RH or D itself.

**Not established:** any identity with God, any universal physical observer, or an implementation as a thermodynamic Maxwell demon.

## References

[1] Bhaskar Bagchi, "On Nyman, Beurling and Baez-Duarte's Hilbert space reformulation of the Riemann hypothesis," Proceedings of the Indian Academy of Sciences (Mathematical Sciences) 116 (2006), 137–146. arXiv:math/0607733. Theorems 1, 2, 5, 7 and the Mellin calculation. The arXiv PDF's printed header contains an inconsistent year; the publication metadata is 2006.

[2] Luis Báez-Duarte, "A strengthening of the Nyman-Beurling criterion for the Riemann Hypothesis," and the second version, arXiv:math/0202141 and arXiv:math/0205003.

[3] Arne Beurling, "A closure problem related to the Riemann zeta-function," Proceedings of the National Academy of Sciences 41 (1955), 312–314. DOI:10.1073/pnas.41.5.312. Continuous-parameter criterion; see also [1] for explicit formulas and proofs.

[4] NIST Digital Library of Mathematical Functions, Section 25.2, Definition and Expansions. The zeta function has meromorphic continuation with a simple pole at 1.

[5] Takahiro Sagawa and Masahito Ueda, "Generalized Jarzynski Equality under Nonequilibrium Feedback Control," Physical Review Letters 104 (2010), 090602. DOI:10.1103/PhysRevLett.104.090602; arXiv:0907.4914v3, equation (3).
