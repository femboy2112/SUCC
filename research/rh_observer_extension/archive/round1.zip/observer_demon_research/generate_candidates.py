#!/usr/bin/env python3
"""Numerical candidate proposal; verify.py is the exact independent arithmetic check.
Requires NumPy and SciPy. No numerical optimization output is itself a certificate.
"""
from fractions import Fraction
from math import lcm
from pathlib import Path
import json
import numpy as np
from scipy.special import digamma


def solve_exact(a, b):
    a = [list(row) + [v] for row, v in zip(a,b)]
    N = len(b)
    for j in range(N):
        p = next(i for i in range(j,N) if a[i][j])
        a[j],a[p]=a[p],a[j]
        d=a[j][j]
        a[j]=[x/d for x in a[j]]
        for i in range(N):
            if i!=j:
                d=a[i][j]
                a[i]=[x-d*y for x,y in zip(a[i],a[j])]
    return [row[-1] for row in a]


def gram(K):
    out=np.zeros((K,K))
    for i,k in enumerate(range(2,K+2)):
        for j,l in enumerate(range(2,k+1)):
            L=lcm(k,l); r=np.arange(1,L+1,dtype=float)
            # Sum_{m>=0} 1/[(Lm+r)(Lm+r+1)] by telescoping digamma.
            w=(digamma((r+1)/L)-digamma(r/L))/L
            out[i,j]=out[j,i]=np.dot((r%k)/k*(r%l)/l,w)
    return out


def candidate(N,K):
    G=gram(K)
    n=np.arange(1,N+1)[:,None]; k=np.arange(2,K+2)[None,:]
    A=(n%k)/k
    Z=np.linalg.solve(G,A.T)
    floated=Z@np.linalg.solve(A@Z,np.ones(N))
    # Round the free variables and repair the prefix constraints EXACTLY.
    c={k:Fraction(float(floated[k-2])).limit_denominator(1_000_000)
       for k in range(N+2,K+2)}
    a=[[Fraction(n%k,k) for k in range(2,N+2)] for n in range(1,N+1)]
    b=[Fraction(1)-sum((v*Fraction(n%k,k) for k,v in c.items()),Fraction())
       for n in range(1,N+1)]
    c.update({k:v for k,v in zip(range(2,N+2),solve_exact(a,b))})
    return {str(k):str(v) for k,v in sorted(c.items()) if v}

records=[]
for N,K in ((1,1),(2,2),(4,8),(8,16),(16,32)):
    records.append({'name':f'bounded_extension_N{N}', 'prefix_length':N,
                    'coefficients':candidate(N,K), 'expected':'CERTIFIED_LT_1'})
records.append({'name':'stress_test_2N_policy_N48', 'prefix_length':48,
                'coefficients':candidate(48,96), 'expected':'CERTIFIED_GT_1'})
records.append({'name':'hostile_minimal_prefix_interpolant_N4', 'prefix_length':4,
                'coefficients':{'2':'1','3':'1','5':'5/6'},
                'expected':'CERTIFIED_GT_1'})
Path(__file__).with_name('certificates.json').write_text(json.dumps(records,indent=2)+'\n')
print('Wrote proposals. Run verify.py for exact validation.')
