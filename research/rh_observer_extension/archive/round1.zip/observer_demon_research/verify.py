#!/usr/bin/env python3
"""Exact finite controls for the RH/observer-completeness research note.

Python standard library only. This verifies finite certificates, NOT RH.
The infinite norm upper bound is rational, with an explicit full-tail bound.
"""
from __future__ import annotations
import argparse
from decimal import Decimal, localcontext
from fractions import Fraction
import json
from math import lcm
from pathlib import Path
from typing import Iterable


def residue(n: int, k: int) -> Fraction:
    if n < 1 or k < 2:
        raise ValueError('Require n >= 1 and k >= 2.')
    return Fraction(n % k, k)


def determinant(matrix: list[list[Fraction]]) -> Fraction:
    a = [row[:] for row in matrix]
    n = len(a)
    if any(len(row) != n for row in a):
        raise ValueError('Matrix must be square.')
    ans = Fraction(1)
    for j in range(n):
        pivot = next((i for i in range(j, n) if a[i][j]), None)
        if pivot is None:
            return Fraction(0)
        if pivot != j:
            a[j], a[pivot] = a[pivot], a[j]
            ans = -ans
        p = a[j][j]
        ans *= p
        for i in range(j + 1, n):
            q = a[i][j] / p
            for k in range(j + 1, n):
                a[i][k] -= q * a[j][k]
            a[i][j] = Fraction(0)
    return ans


def evaluate(coefficients: dict[int, Fraction], n: int) -> Fraction:
    return sum((c * residue(n, k) for k, c in coefficients.items()), Fraction(0))


def norm_enclosure(coefficients: dict[int, Fraction], cutoff: int = 100_000,
                   precision_bits: int = 80) -> tuple[Fraction, Fraction]:
    """Enclose sum_{n>=1} f(n)^2/[n(n+1)], f=sum c_k {n/k}.

    Floor each finite summand to an exact dyadic rational, then allow at most
    cutoff / 2**precision_bits for rounding and (sum|c_k|)^2/(cutoff+1)
    for the ENTIRE omitted tail. No floating point is used.
    """
    if cutoff < 1 or precision_bits < 1 or not coefficients:
        raise ValueError('Invalid norm enclosure arguments.')
    coefficients = {k: Fraction(c) for k, c in coefficients.items() if c}
    if any(k < 2 for k in coefficients):
        raise ValueError('Probe indices must be >= 2.')
    denomin = 1
    for k, c in coefficients.items():
        denomin = lcm(denomin, (c / k).denominator)
    terms = [(k, int(denomin * c / k)) for k, c in coefficients.items()]
    scale = 1 << precision_bits
    denom_sq = denomin * denomin
    accum = 0
    for n in range(1, cutoff + 1):
        numerator = sum(a * (n % k) for k, a in terms)
        accum += (numerator * numerator * scale) // (denom_sq * n * (n + 1))
    lower = Fraction(accum, scale)
    bound = sum((abs(c) for c in coefficients.values()), Fraction(0))
    upper = lower + Fraction(cutoff, scale) + bound * bound / (cutoff + 1)
    return lower, upper


def decimal_string(q: Fraction) -> str:
    with localcontext() as ctx:
        ctx.prec = 30
        return str(Decimal(q.numerator) / Decimal(q.denominator))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cutoff', type=int, default=100_000)
    parser.add_argument('--certificates', type=Path,
                        default=Path(__file__).with_name('certificates.json'))
    parser.add_argument('--output', type=Path,
                        default=Path(__file__).with_name('verification_results.json'))
    args = parser.parse_args()
    controls = []
    # The all-N determinant identity is proved in the note. These are regressions.
    for N in range(1, 25):
        a = [[residue(n, k) for k in range(2, N + 2)] for n in range(1, N + 1)]
        assert determinant(a) == Fraction(1, N + 1)
    controls.append({'name': 'finite determinants', 'scope': 'N=1,...,24', 'status': 'PASS'})
    # Deleting the fractional-part operation collapses the matrix to rank one.
    for N in range(2, 9):
        a = [[Fraction(n, k) for k in range(2, N + 2)] for n in range(1, N + 1)]
        assert determinant(a) == 0
    controls.append({'name': 'fractional-part mutation', 'scope': 'N=2,...,8', 'status': 'PASS'})
    # All finite sections of I-2S* are invertible, but it has an infinite null vector.
    for n in range(1, 101):
        h_n, h_next = Fraction(1, 2 ** (n - 1)), Fraction(1, 2 ** n)
        assert h_n - 2 * h_next == 0
    for N in range(1, 13):
        a = [[Fraction(int(i == j) - 2 * int(j == i + 1))
              for j in range(N)] for i in range(N)]
        assert determinant(a) == 1
    controls.append({'name': 'finite-invertibility hostile control',
                     'scope': '12 finite sections; 100 recurrence checks', 'status': 'PASS'})
    # A nonzero intra-cell signal is invisible to every integer Beurling probe.
    # Equal-length +1/-1 pieces within (1/2,1) have zero integral.
    assert Fraction(1, 4) - Fraction(1, 4) == 0
    controls.append({'name': 'carrier enlargement control',
                     'scope': 'explicit zero-mean intra-cell signal', 'status': 'PASS'})
    results = []
    for record in json.loads(args.certificates.read_text()):
        c = {int(k): Fraction(v) for k, v in record['coefficients'].items()}
        N = record['prefix_length']
        assert all(evaluate(c, n) == 1 for n in range(1, N + 1))
        lo, hi = norm_enclosure(c, cutoff=args.cutoff)
        status = 'CERTIFIED_LT_1' if hi < 1 else ('CERTIFIED_GT_1' if lo > 1 else 'AMBIGUOUS')
        assert status == record['expected'], (record['name'], status, lo, hi)
        results.append({'name': record['name'], 'prefix_length': N,
                        'largest_probe': max(c), 'squared_norm_lower': str(lo),
                        'squared_norm_upper': str(hi),
                        'lower_decimal': decimal_string(lo),
                        'upper_decimal': decimal_string(hi), 'status': status})
    output = {'claim_scope': 'Finite rational certificates and controls only; not a proof of RH.',
              'cutoff': args.cutoff, 'precision_bits': 80,
              'controls': controls, 'certificates': results}
    args.output.write_text(json.dumps(output, indent=2) + '\n')
    print(json.dumps(output, indent=2))

if __name__ == '__main__':
    main()
