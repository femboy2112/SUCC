import ZSCCarryFlux
import Lean.Elab.Command
import Lean.Elab.Print
import Lean.Util.CollectAxioms

/- Kernel-environment export, used after building the exact local theorem sources.
The raw Expr contains every binder, hypothesis and conclusion. An English label
is never a proposition identifier. The enclosing build record is not self-authenticating.
-/
open Lean Elab Command

elab "#succ_export " id:ident : command => do
  let names ← liftCoreM <| realizeGlobalConstWithInfos id
  if names.length != 1 then
    throwError "expected one fully qualified theorem name"
  for name in names do
    let ci ← getConstInfo name
    match ci with
    | .thmInfo _ => pure ()
    | _ => throwError "exported declaration is not a theorem: {name}"
    let axioms ← collectAxioms name
    let record := Json.mkObj [
      ("name", toJson name.toString),
      ("type_expr", toJson (reprStr ci.type)),
      ("universe_parameters", toJson (ci.levelParams.map Name.toString)),
      ("axioms", toJson ((axioms.qsort Name.lt).toList.map Name.toString))]
    logInfo m!"SUCC_THEOREM_JSON {record.compress}"

#check @ObservationalSUCC.ZSCCarryFlux.zsc06_null_partial_fraction
#print axioms ObservationalSUCC.ZSCCarryFlux.zsc06_null_partial_fraction
#succ_export ObservationalSUCC.ZSCCarryFlux.zsc06_null_partial_fraction
#check @ObservationalSUCC.ZSCCarryFlux.zsc06_sixteen_factorisation
#print axioms ObservationalSUCC.ZSCCarryFlux.zsc06_sixteen_factorisation
#succ_export ObservationalSUCC.ZSCCarryFlux.zsc06_sixteen_factorisation
#check @ObservationalSUCC.ZSCCarryFlux.zsc06_authentic_numerator
#print axioms ObservationalSUCC.ZSCCarryFlux.zsc06_authentic_numerator
#succ_export ObservationalSUCC.ZSCCarryFlux.zsc06_authentic_numerator
#check @ObservationalSUCC.ZSCCarryFlux.zsc06_null_numerator
#print axioms ObservationalSUCC.ZSCCarryFlux.zsc06_null_numerator
#succ_export ObservationalSUCC.ZSCCarryFlux.zsc06_null_numerator
#check @ObservationalSUCC.ZSCCarryFlux.zsc06_null_coefficient_vector
#print axioms ObservationalSUCC.ZSCCarryFlux.zsc06_null_coefficient_vector
#succ_export ObservationalSUCC.ZSCCarryFlux.zsc06_null_coefficient_vector
#check @ObservationalSUCC.ZSCCarryFlux.zsc06_null_coeff
#print axioms ObservationalSUCC.ZSCCarryFlux.zsc06_null_coeff
#succ_export ObservationalSUCC.ZSCCarryFlux.zsc06_null_coeff
#check @ObservationalSUCC.ZSCCarryFlux.zsc06_hostile_numerator
#print axioms ObservationalSUCC.ZSCCarryFlux.zsc06_hostile_numerator
#succ_export ObservationalSUCC.ZSCCarryFlux.zsc06_hostile_numerator
#check @ObservationalSUCC.ZSCCarryFlux.zsc06_null_integral
#print axioms ObservationalSUCC.ZSCCarryFlux.zsc06_null_integral
#succ_export ObservationalSUCC.ZSCCarryFlux.zsc06_null_integral
#check @ObservationalSUCC.ZSCCarryFlux.zsc06_null_period_integral
#print axioms ObservationalSUCC.ZSCCarryFlux.zsc06_null_period_integral
#succ_export ObservationalSUCC.ZSCCarryFlux.zsc06_null_period_integral
#check @ObservationalSUCC.ZSCCarryFlux.zsc06_L_A0_eq_zero
#print axioms ObservationalSUCC.ZSCCarryFlux.zsc06_L_A0_eq_zero
#succ_export ObservationalSUCC.ZSCCarryFlux.zsc06_L_A0_eq_zero
#check @ObservationalSUCC.ZSCCarryFlux.zsc02_locality_run_zero
#print axioms ObservationalSUCC.ZSCCarryFlux.zsc02_locality_run_zero
#succ_export ObservationalSUCC.ZSCCarryFlux.zsc02_locality_run_zero
#check @ObservationalSUCC.ZSCCarryFlux.zsc02_locality_run
#print axioms ObservationalSUCC.ZSCCarryFlux.zsc02_locality_run
#succ_export ObservationalSUCC.ZSCCarryFlux.zsc02_locality_run
#check @ObservationalSUCC.ZSCCarryFlux.zsc02_locality_change_zero
#print axioms ObservationalSUCC.ZSCCarryFlux.zsc02_locality_change_zero
#succ_export ObservationalSUCC.ZSCCarryFlux.zsc02_locality_change_zero
#check @ObservationalSUCC.ZSCCarryFlux.zsc02_locality_change
#print axioms ObservationalSUCC.ZSCCarryFlux.zsc02_locality_change
#succ_export ObservationalSUCC.ZSCCarryFlux.zsc02_locality_change
#check @ObservationalSUCC.ZSCCarryFlux.zsc02_two_digit_form
#print axioms ObservationalSUCC.ZSCCarryFlux.zsc02_two_digit_form
#succ_export ObservationalSUCC.ZSCCarryFlux.zsc02_two_digit_form
#check @ObservationalSUCC.ZSCCarryFlux.zsc03_renewal_kernel
#print axioms ObservationalSUCC.ZSCCarryFlux.zsc03_renewal_kernel
#succ_export ObservationalSUCC.ZSCCarryFlux.zsc03_renewal_kernel
#check @ObservationalSUCC.ZSCCarryFlux.rPi_succ_pos
#print axioms ObservationalSUCC.ZSCCarryFlux.rPi_succ_pos
#succ_export ObservationalSUCC.ZSCCarryFlux.rPi_succ_pos
#check @ObservationalSUCC.ZSCCarryFlux.rPi_succ_le
#print axioms ObservationalSUCC.ZSCCarryFlux.rPi_succ_le
#succ_export ObservationalSUCC.ZSCCarryFlux.rPi_succ_le
#check @ObservationalSUCC.ZSCCarryFlux.rPi_succ_antitone
#print axioms ObservationalSUCC.ZSCCarryFlux.rPi_succ_antitone
#succ_export ObservationalSUCC.ZSCCarryFlux.rPi_succ_antitone
#check @ObservationalSUCC.ZSCCarryFlux.zsc03_window
#print axioms ObservationalSUCC.ZSCCarryFlux.zsc03_window
#succ_export ObservationalSUCC.ZSCCarryFlux.zsc03_window
#check @ObservationalSUCC.ZSCCarryFlux.zsc03_renewal_authentic
#print axioms ObservationalSUCC.ZSCCarryFlux.zsc03_renewal_authentic
#succ_export ObservationalSUCC.ZSCCarryFlux.zsc03_renewal_authentic
#check @ObservationalSUCC.ZSCCarryFlux.Jn_le_iff
#print axioms ObservationalSUCC.ZSCCarryFlux.Jn_le_iff
#succ_export ObservationalSUCC.ZSCCarryFlux.Jn_le_iff
#check @ObservationalSUCC.ZSCCarryFlux.zsc03_J_ge
#print axioms ObservationalSUCC.ZSCCarryFlux.zsc03_J_ge
#succ_export ObservationalSUCC.ZSCCarryFlux.zsc03_J_ge
#check @ObservationalSUCC.ZSCCarryFlux.zsc03_renewal_lemma
#print axioms ObservationalSUCC.ZSCCarryFlux.zsc03_renewal_lemma
#succ_export ObservationalSUCC.ZSCCarryFlux.zsc03_renewal_lemma
#check @ObservationalSUCC.ZSCCarryFlux.refute_null_integral_numerator
#print axioms ObservationalSUCC.ZSCCarryFlux.refute_null_integral_numerator
#succ_export ObservationalSUCC.ZSCCarryFlux.refute_null_integral_numerator
#check @ObservationalSUCC.ZSCCarryFlux.refute_partial_fraction_sign_flip
#print axioms ObservationalSUCC.ZSCCarryFlux.refute_partial_fraction_sign_flip
#succ_export ObservationalSUCC.ZSCCarryFlux.refute_partial_fraction_sign_flip
#check @ObservationalSUCC.ZSCCarryFlux.refute_null_numerator_coefficient
#print axioms ObservationalSUCC.ZSCCarryFlux.refute_null_numerator_coefficient
#succ_export ObservationalSUCC.ZSCCarryFlux.refute_null_numerator_coefficient
#check @ObservationalSUCC.ZSCCarryFlux.refute_sixteen_factorisation
#print axioms ObservationalSUCC.ZSCCarryFlux.refute_sixteen_factorisation
#succ_export ObservationalSUCC.ZSCCarryFlux.refute_sixteen_factorisation
#check @ObservationalSUCC.ZSCCarryFlux.refute_locality_change_threshold
#print axioms ObservationalSUCC.ZSCCarryFlux.refute_locality_change_threshold
#succ_export ObservationalSUCC.ZSCCarryFlux.refute_locality_change_threshold
#check @ObservationalSUCC.ZSCCarryFlux.refute_locality_run_constant
#print axioms ObservationalSUCC.ZSCCarryFlux.refute_locality_run_constant
#succ_export ObservationalSUCC.ZSCCarryFlux.refute_locality_run_constant
#check @ObservationalSUCC.ZSCCarryFlux.refute_window_four_n
#print axioms ObservationalSUCC.ZSCCarryFlux.refute_window_four_n
#succ_export ObservationalSUCC.ZSCCarryFlux.refute_window_four_n
#check @ObservationalSUCC.ZSCCarryFlux.refute_renewal_kernel_overrun
#print axioms ObservationalSUCC.ZSCCarryFlux.refute_renewal_kernel_overrun
#succ_export ObservationalSUCC.ZSCCarryFlux.refute_renewal_kernel_overrun
#check @ObservationalSUCC.ZSCCarryFlux.refute_renewal_lemma_overrun
#print axioms ObservationalSUCC.ZSCCarryFlux.refute_renewal_lemma_overrun
#succ_export ObservationalSUCC.ZSCCarryFlux.refute_renewal_lemma_overrun
