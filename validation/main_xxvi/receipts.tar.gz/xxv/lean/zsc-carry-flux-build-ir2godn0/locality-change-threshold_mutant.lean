import ZSCCarryFlux
open Polynomial
open ObservationalSUCC.ZSCCarryFlux
example : ∀ (ξ : ℝ) (n : ℕ), |15 * (16 ^ n * ξ) - round (15 * (16 ^ n * ξ))| < 1 / 200 → hexDigit ξ n = hexDigit ξ (n + 1) :=
  zsc02_locality_change
