import ZSCCarryFlux
open Polynomial
open ObservationalSUCC.ZSCCarryFlux
example : ∀ (ξ : ℝ) (n k : ℕ), (∀ i < k, hexDigit ξ (n + i) = hexDigit ξ n) → |15 * (16 ^ n * ξ) - round (15 * (16 ^ n * ξ))| ≤ 15 / 16 ^ k :=
  zsc02_locality_run
