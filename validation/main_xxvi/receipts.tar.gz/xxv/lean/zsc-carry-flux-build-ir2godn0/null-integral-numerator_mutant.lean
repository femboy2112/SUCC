import ZSCCarryFlux
open Polynomial
open ObservationalSUCC.ZSCCarryFlux
example : ∫ z in (0:ℝ)..1, (z ^ 2 - 4 * z + 3) / ((2 - z ^ 2) * (z ^ 2 - 2 * z + 2)) = 0 :=
  zsc06_null_integral
