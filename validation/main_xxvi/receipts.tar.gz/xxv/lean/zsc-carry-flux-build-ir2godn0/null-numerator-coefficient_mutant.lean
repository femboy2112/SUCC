import ZSCCarryFlux
open Polynomial
open ObservationalSUCC.ZSCCarryFlux
example : ((X ^ 2 + 2) * (X ^ 2 + 2 * X + 2)) * (X ^ 2 - 4 * X + 2 : ℚ[X]) = 8 - 8 * X - 4 * X ^ 2 + 8 * X ^ 3 - 2 * X ^ 4 - 2 * X ^ 5 + X ^ 6 :=
  zsc06_null_numerator
