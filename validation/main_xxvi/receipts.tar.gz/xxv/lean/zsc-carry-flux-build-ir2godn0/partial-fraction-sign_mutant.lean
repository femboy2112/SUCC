import ZSCCarryFlux
open Polynomial
open ObservationalSUCC.ZSCCarryFlux
example : ∀ z : ℚ, z ^ 2 - 2 ≠ 0 → z ^ 2 - 2 * z + 2 ≠ 0 → (z ^ 2 - 4 * z + 2) / ((2 - z ^ 2) * (z ^ 2 - 2 * z + 2)) = z / (z ^ 2 - 2) + (z - 1) / (z ^ 2 - 2 * z + 2) :=
  fun z h1 h2 => zsc06_null_partial_fraction z h1 h2
