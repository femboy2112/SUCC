import ZSCCarryFlux
open Polynomial
open ObservationalSUCC.ZSCCarryFlux
example : ¬ (∀ z : ℚ, z ^ 2 - 2 ≠ 0 → z ^ 2 - 2 * z + 2 ≠ 0 → (z ^ 2 - 4 * z + 2) / ((2 - z ^ 2) * (z ^ 2 - 2 * z + 2)) = z / (z ^ 2 - 2) + (z - 1) / (z ^ 2 - 2 * z + 2)) :=
  refute_partial_fraction_sign_flip
