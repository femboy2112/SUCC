import ZSCCarryFlux
open Polynomial
open ObservationalSUCC.ZSCCarryFlux
example : ¬ (∀ (U r : ℕ → ℝ) (n J : ℕ), (∀ m, U (m + 1) = 16 * U m + r (m + 1)) → (∀ i, 0 ≤ r (n + 1 + i)) → (∀ i, r (n + 1 + i) ≤ r (n + 1)) → ⌊U (n + 1)⌋ - 16 * ⌊U n⌋ = 16 → 16 / 15 * 16 ^ J * r (n + 1) ≤ 1 → ∀ j, 1 ≤ j → j ≤ J + 1 → ⌊U (n + 1 + j)⌋ - 16 * ⌊U (n + j)⌋ = 0) :=
  refute_renewal_kernel_overrun
