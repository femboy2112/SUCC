import ZSCCarryFlux
open Polynomial
open ObservationalSUCC.ZSCCarryFlux
example : ¬ (∀ (U : ℕ → ℝ) (n : ℕ), (∀ m, U (m + 1) = 16 * U m + rPi (m + 1)) → ⌊U (n + 1)⌋ - 16 * ⌊U n⌋ = 16 → ∀ j : ℕ, 1 ≤ j → (j : ℤ) ≤ Jn n + 1 → ⌊U (n + 1 + j)⌋ - 16 * ⌊U (n + j)⌋ = 0) :=
  refute_renewal_lemma_overrun
