import ZSCCarryFlux
open Polynomial
open ObservationalSUCC.ZSCCarryFlux
example : (16 - X ^ 8 : ℚ[X]) = ((X ^ 2 + 2) * (X ^ 2 + 2 * X + 2)) * ((2 - X ^ 2) * (X ^ 2 - 2 * X + 2)) :=
  zsc06_sixteen_factorisation
