import ZSCCarryFlux
open Polynomial
open ObservationalSUCC.ZSCCarryFlux
example : ∀ n L : ℕ, 1 ≤ n → 4 ^ L ≤ 4 * n → 16 / 15 * 16 ^ L * rPi (n + 1) ≤ 1 :=
  zsc03_window
